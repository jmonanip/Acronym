package com.mydomain.acronymsapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import com.mydomain.acronymsapp.lookup.LookupAcronymFragment
import com.mydomain.acronymsapp.lookup.LookupAcronymViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var searchView: SearchView
    private lateinit var lookupAcronymViewModel: LookupAcronymViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        searchView = findViewById(R.id.search_view)
        lookupAcronymViewModel = ViewModelProvider(this).get(LookupAcronymViewModel::class.java)
        initializeLookupScreen(savedInstanceState)
        initializeSearchView()
    }

    private fun initializeLookupScreen(savedInstanceState: Bundle?) {
        if (savedInstanceState != null) {
            return
        }

        val lookupAcronymFragment = LookupAcronymFragment().getInstance()
        supportFragmentManager.beginTransaction()
            .add(R.id.fragment_container, lookupAcronymFragment)
            .commit()
        title = TITLE
    }

    private fun initializeSearchView() {
        searchView.queryHint = getString(R.string.search_acronym_hint)
        searchView.isIconified = false
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (!query.isNullOrEmpty()) {
                    lookupAcronymViewModel.lookupAcronym(query)
                    searchView.clearFocus()
                    return true
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText.isNullOrEmpty()) {
                    lookupAcronymViewModel.clearAcronymData()
                }
                return false
            }
        })
        searchView.setOnCloseListener {
            lookupAcronymViewModel.clearAcronymData()
            false
        }
    }

    companion object {
        const val TAG = "MainActivity"
        const val TITLE = "Lookup Acronym"
    }
}